import os
import uuid
import pandas as pd
import matplotlib.pyplot as plt
import folium
from flask import Flask, render_template, request, redirect, url_for, session, flash
from sklearn.cluster import KMeans

app = Flask(__name__)
app.secret_key = "supersecretkey"  # For session management
UPLOAD_FOLDER = "static/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# Define segmentation types
SEGMENTATION_TYPES = {
    "Demographic": ["Annual Income (k$)", "Age"],
    "Behavioral": ["Spending Score (1-100)", "Annual Income (k$)"],
    "Psychographic": ["Spending Score (1-100)", "Age"],
    "Geographic": ["Latitude", "Longitude"]
}

def clear_old_plots():
    """Remove old scatter plots to prevent caching issues."""
    for file in os.listdir("static"):
        if file.startswith("scatter_") or file.startswith("map_"):
            os.remove(os.path.join("static", file))

def perform_clustering(file_path, segmentation_type):
    """Load CSV, apply K-Means clustering based on selected segmentation type."""
    df = pd.read_csv(file_path)
    df.columns = df.columns.str.strip()  # Remove spaces from column names

    if segmentation_type not in SEGMENTATION_TYPES:
        raise ValueError("Invalid segmentation type selected.")

    required_columns = SEGMENTATION_TYPES[segmentation_type]
    missing_columns = [col for col in required_columns if col not in df.columns]

    if missing_columns:
        raise ValueError(f"Missing columns in dataset: {', '.join(missing_columns)}")

    if segmentation_type == "Geographic":
        df["Latitude"] = df["Latitude"].fillna(0)
        df["Longitude"] = df["Longitude"].fillna(0)

    X = df[required_columns]

    kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
    df["Cluster"] = kmeans.fit_predict(X)

    return df

def generate_scatter_plot(df, segmentation_type):
    """Generate scatter plot for selected segmentation type."""
    clear_old_plots()  # ✅ Clears old plots before generating a new one

    plt.figure(figsize=(8, 5))
    x_col, y_col = SEGMENTATION_TYPES[segmentation_type]
    df["Cluster"] = df["Cluster"].astype(int)

    for cluster in df["Cluster"].unique():
        cluster_data = df[df["Cluster"] == cluster]
        plt.scatter(cluster_data[x_col], cluster_data[y_col], label=f"Cluster {cluster}")

    plt.xlabel(x_col)
    plt.ylabel(y_col)
    plt.title(f"Customer Segmentation - {segmentation_type}")
    plt.legend()

    plot_filename = f"static/scatter_{uuid.uuid4().hex[:8]}.png"
    plt.savefig(plot_filename)
    plt.close()

    return plot_filename

def generate_geographic_map(df):
    """Generate an interactive map for geographic segmentation."""
    map_center = [df["Latitude"].mean(), df["Longitude"].mean()]
    m = folium.Map(location=map_center, zoom_start=2)

    clusters = df["Cluster"].unique()
    colors = ["red", "blue", "green", "purple", "orange"]

    for _, row in df.iterrows():
        folium.CircleMarker(
            location=[row["Latitude"], row["Longitude"]],
            radius=5,
            color=colors[row["Cluster"] % len(colors)],
            fill=True,
            fill_color=colors[row["Cluster"] % len(colors)],
            popup=row.get("Name", "Unknown")
        ).add_to(m)

    map_path = "static/map_geographic.html"
    m.save(map_path)
    return map_path

@app.route("/")
def index():
    return render_template("index.html", segmentation_types=SEGMENTATION_TYPES.keys())

@app.route("/upload", methods=["GET", "POST"])
def upload():
    if request.method == "POST":
        selected_type = request.form.get("segmentation_type")
        if not selected_type:
            flash("Please select a segmentation type.", "error")
            return redirect(url_for("index"))
        
        session["selected_type"] = selected_type
        return redirect(url_for("file_upload"))
    
    return redirect(url_for("index"))

@app.route("/file_upload", methods=["GET", "POST"])
def file_upload():
    selected_type = session.get("selected_type", None)
    
    if request.method == "POST":
        if "file" not in request.files:
            flash("No file uploaded.", "error")
            return redirect(url_for("file_upload"))
        
        file = request.files["file"]
        if file.filename == "":
            flash("Please select a file to upload.", "error")
            return redirect(url_for("file_upload"))

        file_path = os.path.join(app.config["UPLOAD_FOLDER"], "uploaded.csv")
        file.save(file_path)
        session["file_path"] = file_path

        return redirect(url_for("analyze"))
    
    return render_template("upload.html", selected_type=selected_type)

@app.route("/analyze")
def analyze():
    selected_type = session.get("selected_type", None)
    file_path = session.get("file_path", None)

    if not selected_type or not file_path:
        flash("Session expired or invalid request.", "error")
        return redirect(url_for("index"))

    try:
        df = perform_clustering(file_path, selected_type)
    except ValueError as e:
        flash(str(e), "error")
        return redirect(url_for("file_upload"))

    if selected_type == "Geographic":
        map_file = generate_geographic_map(df)
        return render_template("result.html", selected_type=selected_type, map_file=map_file)

    scatter_plot = generate_scatter_plot(df, selected_type)
    return render_template("result.html", selected_type=selected_type, scatter_plot=scatter_plot)

if __name__ == "__main__":
    app.run(debug=True)
